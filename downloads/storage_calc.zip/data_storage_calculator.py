import tkinter as tk
from tkinter import messagebox
import re

# Constants for binary conversion
CONVERSION_FACTOR = 1024.0  # 1 GB = 1024 MB, 1 TB = 1024 GB

def calculate_and_display():
    """
    Calculates the total storage in GB from input text, then displays the result
    in MB, GB, and TB based on the selected radio button.
    """
    input_text = text_input.get("1.0", tk.END)

    # Regex to find numbers followed by TB, GB, or MB
    pattern = re.compile(r'(\d+\.?\d*)\s*(TB|GB|MB)', re.IGNORECASE)
    matches = pattern.findall(input_text)

    total_gb = 0.0

    if not matches:
        messagebox.showerror("Error", "No valid TB, GB, or MB values found in the input.")
        update_result_labels(0.0)
        return

    # Process each match and accumulate total in GB
    for value_str, unit in matches:
        try:
            value = float(value_str)
            unit_upper = unit.upper()

            if unit_upper == 'TB':
                total_gb += value * CONVERSION_FACTOR
            elif unit_upper == 'GB':
                total_gb += value
            elif unit_upper == 'MB':
                total_gb += value / CONVERSION_FACTOR
        except ValueError:
            continue

    # Update all result labels
    update_result_labels(total_gb)

def update_result_labels(total_gb):
    """
    Converts the total_gb into MB, GB, and TB, and updates the labels.
    """
    # Calculate all three units
    total_mb = total_gb * CONVERSION_FACTOR
    total_tb = total_gb / CONVERSION_FACTOR

    # Get the selected display unit
    selected_unit = display_unit_var.get()

    # Determine which unit to display
    if selected_unit == "MB":
        result = f"{total_mb:.2f} MB"
    elif selected_unit == "TB":
        result = f"{total_tb:.4f} TB" # Use higher precision for TB
    else: # Default is GB
        result = f"{total_gb:.2f} GB"

    # Update the result label
    result_label.config(text=f"Total Storage: {result}")


def clear_input():
    """Clears the input text area and resets the result label."""
    text_input.delete("1.0", tk.END)
    # Reset the labels to 0.00 GB
    result_label.config(text="Total Storage: 0.00 GB")


# --- GUI Setup ---

root = tk.Tk()
root.title("Data Storage Calculator (TB, GB, MB)")
root.geometry("500x450")

# Instruction Label
instruction_label = tk.Label(
    root,
    text="Enter data storage values:\n(e.g., 2.5 TB, 11.13 GB, 611.71 MB, separate by commas or spaces):",
    padx=10,
    pady=10
)
instruction_label.pack()

# Text Input Area
text_input = tk.Text(root, height=10, width=60, wrap="word")
text_input.pack(padx=10, pady=5)

# Calculate Button
calculate_button = tk.Button(
    root,
    text="Calculate Total Storage",
    command=calculate_and_display,
    bg="green",
    fg="white",
    font=("Arial", 10, "bold")
)
calculate_button.pack(pady=5)

# --- Unit Selection Frame ---
unit_frame = tk.Frame(root)
unit_frame.pack(pady=5)

display_unit_var = tk.StringVar(value="GB") # Default to GB

unit_label = tk.Label(unit_frame, text="Display Unit:")
unit_label.pack(side="left", padx=(0, 10))

# Radio Buttons
mb_radio = tk.Radiobutton(unit_frame, text="MB", variable=display_unit_var, value="MB", command=calculate_and_display)
mb_radio.pack(side="left", padx=5)

gb_radio = tk.Radiobutton(unit_frame, text="GB", variable=display_unit_var, value="GB", command=calculate_and_display)
gb_radio.pack(side="left", padx=5)

tb_radio = tk.Radiobutton(unit_frame, text="TB", variable=display_unit_var, value="TB", command=calculate_and_display)
tb_radio.pack(side="left", padx=5)
# --- End Unit Selection Frame ---

# Clear Button
clear_button = tk.Button(
    root,
    text="Clear Input",
    bg="coral",
    font=("Arial",10,"bold"),
    command=clear_input
)
clear_button.pack(pady=5)

# Result Label
result_label = tk.Label(
    root,
    text="Total Storage: 0.00 GB",
    font=("Arial", 12, "bold"),
    pady=10
)
result_label.pack()

# Start the main event loop
root.mainloop()