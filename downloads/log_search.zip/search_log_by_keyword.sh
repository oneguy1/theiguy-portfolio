#!/bin/bash

# A little script to search entries in a log file based on keywords search.

# Prompt for the log file path
read -p "Enter the full path to the log file: " log_file_path

# Check if the file exists
if [ ! -f "$log_file_path" ]; then
    echo "Error: File not found at '$log_file_path'."
    exit 1
fi

# Prompt for the keywords to search, separated by spaces
read -p "Enter keywords (separated by a space): " search_keywords

echo "---------------------------------------------------"
echo "Searching for keywords in '$log_file_path'..."
echo "---------------------------------------------------"

# Convert the space-separated keywords into a grep-friendly regex
grep_pattern=$(echo "$search_keywords" | sed 's/ /|/g')

# Use grep to find and display matching lines
# The -E flag enables extended regular expressions for the | operator
# The -i flag makes the search case-insensitive
# The --color=always flag highlights the keyword in the output
grep -E --color=always -i "$grep_pattern" "$log_file_path"

echo "---------------------------------------------------"
echo "Search complete."