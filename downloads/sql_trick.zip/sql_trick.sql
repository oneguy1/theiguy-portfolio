{\rtf1\ansi\ansicpg1252\cocoartf2867
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 insert into user_in_group (user_id,group_id,role_id,notification_enabled,creation_time,is_deleted)\
select distinct 	   user_id,4307	   ,3	   ,1			,now()	      ,0 \
from user_in_group \
where user_id not in (select user_id from (select * from user_in_group) a where group_id=4307);}